#include <stdio.h>
#include <stdlib.h>

#ifndef __AFFICHAGE__H__

    #define __AFFICHAGE__H__

    void printBits(char);

#endif
    